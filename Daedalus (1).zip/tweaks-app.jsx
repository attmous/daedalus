// Daedalus tweaks — three feel-shifting controls.
//
// atmosphere → swaps the entire palette mood (Ink / Parchment / Vellum)
// voice      → swaps headline typography (Craftsman / Operator / Inscription)
// ornament   → 0..2 scalar that turns mythic decoration up or down

const DAEDALUS_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "atmosphere": "ink",
  "voice": "craftsman",
  "ornament": 1
}/*EDITMODE-END*/;

function DaedalusTweaks() {
  const [t, setTweak] = useTweaks(DAEDALUS_TWEAK_DEFAULTS);

  // Apply tweak state to the document root. data-* attrs drive CSS variants;
  // --ornament drives a numeric scalar that several rules read.
  React.useEffect(() => {
    const r = document.documentElement;
    r.dataset.atmosphere = t.atmosphere;
    r.dataset.voice = t.voice;
    r.style.setProperty('--ornament', String(t.ornament));
    // Discrete ornament tier (0/1/2) for rules that need a stage, not a scalar.
    const tier = t.ornament <= 0.34 ? 'low' : t.ornament >= 1.34 ? 'high' : 'mid';
    r.dataset.ornament = tier;
  }, [t.atmosphere, t.voice, t.ornament]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Atmosphere" />
      <TweakRadio
        label="Palette mood"
        value={t.atmosphere}
        options={[
          { value: 'ink',       label: 'Ink' },
          { value: 'parchment', label: 'Parchment' },
          { value: 'vellum',    label: 'Vellum' },
        ]}
        onChange={(v) => setTweak('atmosphere', v)}
      />

      <TweakSection label="Voice" />
      <TweakRadio
        label="Headline type"
        value={t.voice}
        options={[
          { value: 'craftsman',   label: 'Craftsman' },
          { value: 'operator',    label: 'Operator' },
          { value: 'inscription', label: 'Inscription' },
        ]}
        onChange={(v) => setTweak('voice', v)}
      />

      <TweakSection label="Mythic density" />
      <TweakSlider
        label="Ornament"
        value={t.ornament}
        min={0}
        max={2}
        step={0.05}
        unit="×"
        onChange={(v) => setTweak('ornament', Number(v.toFixed(2)))}
      />
    </TweaksPanel>
  );
}

const __mount = document.getElementById('tweaks-root');
ReactDOM.createRoot(__mount).render(<DaedalusTweaks />);
